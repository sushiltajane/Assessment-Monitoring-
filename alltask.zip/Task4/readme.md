
![alt text](image.png)

After fixing vulenrabilities

![alt text](image-1.png)

Explanation:

1. Base Image Update (nginx:1.21-alpine → nginx:1.25-alpine)

2. Package Version Updates (Removed Version Pinning)


