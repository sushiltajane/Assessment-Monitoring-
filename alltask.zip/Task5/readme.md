kube-bench on your cluster and list the report

![alt text](image.png)

![alt text](image-1.png)

